const express = require('express');
const serverless = require('serverless-http');
// const { TrafficLightsData } = require('../../TrafficLightsData');  // Adjust path as necessary
const { TrafficLightsData } = require('../../src/TrafficLightsData');

const app = express();
app.use(express.json());

let trafficLights = TrafficLightsData;

app.get('/traffic-lights', (req, res) => {
  res.json(trafficLights);
});

app.get('/traffic-lights/:id', (req, res) => {
  const light = trafficLights.find(tl => tl.id === parseInt(req.params.id));
  if (light) {
    res.json(light);
  } else {
    res.status(404).send('Traffic light not found');
  }
});

app.get('/traffic-lights/:id/state', (req, res) => {
  const { id } = req.params;
  const light = trafficLights.find(tl => tl.id === parseInt(id));
  if (light) {
    res.json(light);  
  } else {
    res.status(404).send('Traffic light not found');
  }
});

app.post('/traffic-lights/:id/state', (req, res) => {
  const { id } = req.params;
  const { color, power } = req.body;
  const light = trafficLights.find(tl => tl.id === parseInt(id));
  if (light) {
    if (color) light.color = color;
    if (typeof power === 'boolean') light.power = power;
    res.json(light);
  } else {
    res.status(404).send('Traffic light not found');
  }
});

module.exports.handler = serverless(app);
