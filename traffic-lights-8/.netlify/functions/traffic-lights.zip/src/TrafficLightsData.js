export const TrafficLightsData = [
  { id: 1, color: "red", description: "Червоний", clickcount: 0, brightness: 1, blinkCount: 3, power: true },
  { id: 2, color: "yellow", description: "Жовтий", clickcount: 0, brightness: 1, blinkCount: 3, power: true },
  { id: 3, color: "green", description: "Зелений", clickcount: 0, brightness: 1, blinkCount: 3, power: true },
];
